const contenedorPoke = document.querySelector('.pokemon-container')

//Realizamos la conexion con la API y establecemos que queremos seleccionar el id
function fetchPokemon(id)
{
    fetch(`https://pokeapi.co/api/v2/pokemon/${id}/`)
    .then((res) => res.json())
    .then((data) =>
    {createPokemon(data);
    }); 
}

//Hacemos un for para seleccionar el numero de pokemons que queremos recorrer
function fetchPokemons(number)
{
    for (let i = 1; i <= number; i++)
    {
        fetchPokemon(i);
    }
}

//Rellenar los datos de nuestro div con los contenidos de la "carta"
function createPokemon(pokemon)
{
    const carta = document.createElement('div');
    carta.classList.add('pokemon-block');

    const spriteContainer = document.createElement('div');
    spriteContainer.classList.add('img-container')

    const sprite = document.createElement('img');
    sprite.src = pokemon.sprites.front_default;

    spriteContainer.appendChild(sprite);

    const number = document.createElement("p");
    number.textContent = `#${pokemon.id.toString().padStart(3, 0)}`;

    const name = document.createElement("p");
    name.classList.add("name");
    name.textContent = pokemon.name;

    carta.appendChild(spriteContainer);
    carta.appendChild(number);
    carta.appendChild(name);

    contenedorPoke.appendChild(carta);
}

fetchPokemons(6);